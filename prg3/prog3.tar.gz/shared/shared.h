#ifndef SHARED_H
#define SHARED_H

#define MAX_GRID 8
#define DURATION 4

#endif
